import './style.css';
import { fetchMovies, searchMovies } from './api.js';
import { saveFavorites, loadFavorites } from './storage.js';

// State
let movies = [];
let favorites = loadFavorites();
let currentView = 'all'; // 'all' or 'favorites'
let isLoading = false;
let error = null;

// DOM Elements
const app = document.querySelector('#app');

// Initialize the app
async function init() {
  renderApp();
  await loadMovies();
}

// Load initial movies
async function loadMovies() {
  try {
    isLoading = true;
    renderMovies();
    
    // Fetch popular movies as initial data
    movies = await fetchMovies();
    
    isLoading = false;
    renderMovies();
  } catch (err) {
    isLoading = false;
    error = 'Failed to load movies. Please try again.';
    renderMovies();
    console.error(err);
  }
}

// Search for movies
async function handleSearch(query) {
  if (!query.trim()) {
    await loadMovies();
    return;
  }
  
  try {
    isLoading = true;
    error = null;
    renderMovies();
    
    movies = await searchMovies(query);
    
    isLoading = false;
    renderMovies();
  } catch (err) {
    isLoading = false;
    error = 'Failed to search movies. Please try again.';
    renderMovies();
    console.error(err);
  }
}

// Toggle favorite status
function toggleFavorite(movieId) {
  const index = favorites.findIndex(id => id === movieId);
  
  if (index === -1) {
    favorites.push(movieId);
  } else {
    favorites.splice(index, 1);
  }
  
  saveFavorites(favorites);
  renderMovies();
}

// Switch between all movies and favorites
function switchView(view) {
  currentView = view;
  renderMovies();
}

// Render the entire app
function renderApp() {
  app.innerHTML = `
    <header>
      <h1>Movie Explorer</h1>
      <div class="search-container">
        <input type="text" id="search-input" placeholder="Search for movies...">
        <button id="search-button">Search</button>
      </div>
    </header>
    
    <div class="tabs">
      <div id="all-tab" class="tab ${currentView === 'all' ? 'active' : ''}">All Movies</div>
      <div id="favorites-tab" class="tab ${currentView === 'favorites' ? 'active' : ''}">Favorites</div>
    </div>
    
    <div id="movies-container"></div>
  `;
  
  // Add event listeners
  document.getElementById('search-button').addEventListener('click', () => {
    const query = document.getElementById('search-input').value;
    handleSearch(query);
  });
  
  document.getElementById('search-input').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      const query = document.getElementById('search-input').value;
      handleSearch(query);
    }
  });
  
  document.getElementById('all-tab').addEventListener('click', () => switchView('all'));
  document.getElementById('favorites-tab').addEventListener('click', () => switchView('favorites'));
}

// Render the movies list
function renderMovies() {
  const container = document.getElementById('movies-container');
  
  if (isLoading) {
    container.innerHTML = '<div class="loading">Loading movies...</div>';
    return;
  }
  
  if (error) {
    container.innerHTML = `<div class="error">${error}</div>`;
    return;
  }
  
  let moviesToRender = movies;
  
  // Filter for favorites view
  if (currentView === 'favorites') {
    moviesToRender = movies.filter(movie => favorites.includes(movie.id));
    
    if (moviesToRender.length === 0) {
      container.innerHTML = '<div class="no-results">No favorite movies yet. Add some!</div>';
      return;
    }
  } else if (movies.length === 0) {
    container.innerHTML = '<div class="no-results">No movies found. Try another search.</div>';
    return;
  }
  
  container.innerHTML = `
    <div class="movie-grid">
      ${moviesToRender.map(movie => renderMovieCard(movie)).join('')}
    </div>
  `;
  
  // Add event listeners for favorite buttons
  document.querySelectorAll('.favorite-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const movieId = parseInt(btn.dataset.id);
      toggleFavorite(movieId);
    });
  });
}

// Render a single movie card
function renderMovieCard(movie) {
  const isFavorite = favorites.includes(movie.id);
  
  return `
    <div class="movie-card">
      <img src="${movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : 'https://via.placeholder.com/500x750?text=No+Image'}" 
           alt="${movie.title}" 
           class="movie-poster">
      <button class="favorite-btn ${isFavorite ? 'active' : ''}" data-id="${movie.id}">
        <i class="fas ${isFavorite ? 'fa-heart' : 'fa-heart'}"></i>
      </button>
      <div class="movie-info">
        <h3 class="movie-title">${movie.title}</h3>
        <div class="movie-rating">
          <i class="fas fa-star star"></i>
          <span>${movie.vote_average.toFixed(1)}/10</span>
        </div>
        <p>${movie.release_date ? new Date(movie.release_date).getFullYear() : 'N/A'}</p>
      </div>
    </div>
  `;
}

// Initialize the app
init();