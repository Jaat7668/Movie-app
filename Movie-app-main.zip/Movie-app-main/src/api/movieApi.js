import axios from 'axios';

// The Movie Database (TMDb) API key
// Note: In a production app, you would store this in an environment variable
const API_KEY = '3fd2be6f0c70a2a598f084ddfb75487c'; // This is a public TMDB API key for demo purposes
const BASE_URL = 'https://api.themoviedb.org/3';

// Fetch popular movies
export async function fetchPopularMovies(page = 1) {
  try {
    const response = await axios.get(`${BASE_URL}/movie/popular`, {
      params: {
        api_key: API_KEY,
        language: 'en-US',
        page
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error fetching popular movies:', error);
    throw error;
  }
}

// Search for movies
export async function searchMovies(query, page = 1) {
  try {
    const response = await axios.get(`${BASE_URL}/search/movie`, {
      params: {
        api_key: API_KEY,
        language: 'en-US',
        query,
        page,
        include_adult: false
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error searching movies:', error);
    throw error;
  }
}

// Get movie details
export async function getMovieDetails(movieId) {
  try {
    const response = await axios.get(`${BASE_URL}/movie/${movieId}`, {
      params: {
        api_key: API_KEY,
        language: 'en-US',
        append_to_response: 'videos,credits'
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error getting movie details:', error);
    throw error;
  }
}

// Get similar movies
export async function getSimilarMovies(movieId, page = 1) {
  try {
    const response = await axios.get(`${BASE_URL}/movie/${movieId}/similar`, {
      params: {
        api_key: API_KEY,
        language: 'en-US',
        page
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error getting similar movies:', error);
    throw error;
  }
}

// Get top rated movies
export async function getTopRatedMovies(page = 1) {
  try {
    const response = await axios.get(`${BASE_URL}/movie/top_rated`, {
      params: {
        api_key: API_KEY,
        language: 'en-US',
        page
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error getting top rated movies:', error);
    throw error;
  }
}