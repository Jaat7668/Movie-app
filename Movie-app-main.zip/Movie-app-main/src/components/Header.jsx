import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import './Header.css';

function Header() {
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const location = useLocation();
  
  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?search=${encodeURIComponent(searchQuery)}`);
    }
  };
  
  return (
    <header className="header">
      <Link to="/" className="logo">
        <h1>Movie Explorer</h1>
      </Link>
      
      <div className="search-container">
        <form onSubmit={handleSearch}>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for movies..."
          />
          <button type="submit">Search</button>
        </form>
      </div>
      
      <nav className="nav-links">
        <Link to="/" className={location.pathname === '/' && !location.search.includes('?search=') ? 'active' : ''}>
          Popular
        </Link>
        <Link to="/?top_rated=true" className={location.search.includes('top_rated=true') ? 'active' : ''}>
          Top Rated
        </Link>
        <Link to="/favorites" className={location.pathname === '/favorites' ? 'active' : ''}>
          Favorites
        </Link>
      </nav>
    </header>
  );
}

export default Header;