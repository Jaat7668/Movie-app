import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getMovieDetails, getSimilarMovies } from '../api/movieApi';
import { useFavorites } from '../contexts/FavoritesContext';
import MovieCard from '../components/MovieCard';
import './MovieDetailsPage.css';

function MovieDetailsPage() {
  const { id } = useParams();
  const movieId = parseInt(id);
  const { isFavorite, toggleFavorite } = useFavorites();
  
  const [movie, setMovie] = useState(null);
  const [similarMovies, setSimilarMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    async function loadMovieDetails() {
      setLoading(true);
      setError(null);
      
      try {
        const movieData = await getMovieDetails(movieId);
        setMovie(movieData);
        document.title = `${movieData.title} - Movie Explorer`;
        
        const similarData = await getSimilarMovies(movieId);
        setSimilarMovies(similarData.results.slice(0, 6)); // Limit to 6 similar movies
      } catch (err) {
        setError('Failed to load movie details. Please try again.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    
    loadMovieDetails();
    
    // Scroll to top when navigating to a new movie
    window.scrollTo(0, 0);
  }, [movieId]);
  
  if (loading) {
    return <div className="loading">Loading movie details...</div>;
  }
  
  if (error) {
    return <div className="error">{error}</div>;
  }
  
  if (!movie) {
    return <div className="error">Movie not found</div>;
  }
  
  const favorited = isFavorite(movieId);
  
  // Format runtime to hours and minutes
  const formatRuntime = (minutes) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };
  
  // Get director from credits
  const director = movie.credits?.crew?.find(person => person.job === 'Director')?.name || 'Unknown';
  
  // Get top cast members
  const topCast = movie.credits?.cast?.slice(0, 5).map(person => person.name).join(', ') || 'Unknown';
  
  // Get production companies with logos
  const productionCompanies = movie.production_companies?.filter(company => company.logo_path);
  
  return (
    <div className="movie-details-page">
      <Link to="/" className="back-button">
        <i className="fas fa-arrow-left"></i> Back to Movies
      </Link>
      
      <div className="movie-details">
        <div className="movie-details-poster">
          <img 
            src={movie.poster_path 
              ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` 
              : 'https://via.placeholder.com/500x750?text=No+Image'} 
            alt={movie.title} 
          />
        </div>
        
        <div className="movie-details-info">
          <div className="movie-details-header">
            <h1 className="movie-details-title">{movie.title}</h1>
            <div className="movie-details-rating">
              <i className="fas fa-star star"></i>
              <span>{movie.vote_average.toFixed(1)}/10</span>
              <button 
                className={`favorite-btn-large ${favorited ? 'active' : ''}`}
                onClick={() => toggleFavorite(movieId)}
              >
                <i className="fas fa-heart"></i>
                {favorited ? 'Remove from Favorites' : 'Add to Favorites'}
              </button>
            </div>
          </div>
          
          <div className="movie-details-meta">
            <span>{movie.release_date ? new Date(movie.release_date).getFullYear() : 'N/A'}</span>
            {movie.runtime && <span>{formatRuntime(movie.runtime)}</span>}
            {movie.vote_count && <span>{movie.vote_count.toLocaleString()} votes</span>}
          </div>
          
          <div className="movie-details-genres">
            {movie.genres.map(genre => (
              <span key={genre.id} className="genre-tag">{genre.name}</span>
            ))}
          </div>
          
          <p className="movie-details-overview">{movie.overview}</p>
          
          <div className="movie-details-crew">
            <div className="crew-item">
              <span className="crew-label">Director:</span>
              <span className="crew-value">{director}</span>
            </div>
            <div className="crew-item">
              <span className="crew-label">Cast:</span>
              <span className="crew-value">{topCast}</span>
            </div>
            {movie.budget > 0 && (
              <div className="crew-item">
                <span className="crew-label">Budget:</span>
                <span className="crew-value">${movie.budget.toLocaleString()}</span>
              </div>
            )}
            {movie.revenue > 0 && (
              <div className="crew-item">
                <span className="crew-label">Revenue:</span>
                <span className="crew-value">${movie.revenue.toLocaleString()}</span>
              </div>
            )}
          </div>
          
          {movie.videos?.results?.length > 0 && (
            <div className="movie-trailer">
              <h3>Trailer</h3>
              <div className="trailer-container">
                <iframe
                  src={`https://www.youtube.com/embed/${movie.videos.results[0].key}`}
                  title={`${movie.title} Trailer`}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            </div>
          )}
          
          {productionCompanies?.length > 0 && (
            <div className="production-companies">
              <h3>Production</h3>
              <div className="companies-list">
                {productionCompanies.slice(0, 3).map(company => (
                  <div key={company.id} className="company-item">
                    <img 
                      src={`https://image.tmdb.org/t/p/w200${company.logo_path}`}
                      alt={company.name}
                      className="company-logo"
                    />
                    <span className="company-name">{company.name}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      
      {similarMovies.length > 0 && (
        <div className="similar-movies">
          <h3>Similar Movies</h3>
          <div className="movie-grid">
            {similarMovies.map(movie => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default MovieDetailsPage;