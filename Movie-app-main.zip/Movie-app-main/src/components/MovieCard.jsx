import React from 'react';
import { Link } from 'react-router-dom';
import { useFavorites } from '../contexts/FavoritesContext';
import './MovieCard.css';

function MovieCard({ movie }) {
  const { isFavorite, toggleFavorite } = useFavorites();
  const favorited = isFavorite(movie.id);
  const isTopRated = movie.vote_average >= 8.0;
  
  const handleFavoriteClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFavorite(movie.id);
  };
  
  return (
    <Link to={`/movie/${movie.id}`} className={`movie-card ${isTopRated ? 'top-rated' : ''}`}>
      <div className="movie-poster-container">
        <img 
          src={movie.poster_path 
            ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` 
            : 'https://via.placeholder.com/500x750?text=No+Image'} 
          alt={movie.title} 
          className="movie-poster"
        />
        <button 
          className={`favorite-btn ${favorited ? 'active' : ''}`}
          onClick={handleFavoriteClick}
          aria-label={favorited ? "Remove from favorites" : "Add to favorites"}
        >
          <i className={`fas fa-heart`}></i>
        </button>
      </div>
      <div className="movie-info">
        <h3 className="movie-title">{movie.title}</h3>
        <div className="movie-meta">
          <div className="movie-rating">
            <i className="fas fa-star star"></i>
            <span>{movie.vote_average.toFixed(1)}</span>
          </div>
          <div className="movie-year">
            {movie.release_date ? new Date(movie.release_date).getFullYear() : 'N/A'}
          </div>
        </div>
      </div>
    </Link>
  );
}

export default MovieCard;