import React, { useState, useEffect } from 'react';
import { useFavorites } from '../contexts/FavoritesContext';
import MovieCard from '../components/MovieCard';
import { getMovieDetails } from '../api/movieApi';
import { Link } from 'react-router-dom';
import './FavoritesPage.css';

function FavoritesPage() {
  const { favorites } = useFavorites();
  const [favoriteMovies, setFavoriteMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    document.title = 'My Favorites - Movie Explorer';
    
    async function loadFavoriteMovies() {
      if (favorites.length === 0) {
        setFavoriteMovies([]);
        setLoading(false);
        return;
      }
      
      setLoading(true);
      setError(null);
      
      try {
        // Fetch details for all favorite movies in parallel
        const moviePromises = favorites.map(id => getMovieDetails(id));
        const movies = await Promise.all(moviePromises);
        setFavoriteMovies(movies);
      } catch (err) {
        setError('Failed to load favorite movies. Please try again.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    
    loadFavoriteMovies();
  }, [favorites]);
  
  if (loading) {
    return <div className="loading">Loading your favorites...</div>;
  }
  
  if (error) {
    return <div className="error">{error}</div>;
  }
  
  if (favoriteMovies.length === 0) {
    return (
      <div className="favorites-empty">
        <h2>My Favorites</h2>
        <div className="empty-message">
          <i className="fas fa-heart empty-heart"></i>
          <p>You haven't added any movies to your favorites yet.</p>
          <p>Discover amazing films and add them to your collection!</p>
          <Link to="/" className="browse-button">
            <i className="fas fa-film"></i> Browse Movies
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="favorites-page">
      <h2>My Favorites</h2>
      <div className="movie-grid">
        {favoriteMovies.map(movie => (
          <MovieCard key={movie.id} movie={movie} />
        ))}
      </div>
    </div>
  );
}

export default FavoritesPage;