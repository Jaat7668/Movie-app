import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import MovieCard from '../components/MovieCard';
import Pagination from '../components/Pagination';
import { fetchPopularMovies, searchMovies, getTopRatedMovies } from '../api/movieApi';
import './HomePage.css';

function HomePage() {
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('search');
  const isTopRated = searchParams.get('top_rated') === 'true';
  
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  
  useEffect(() => {
    // Reset to page 1 when search query or filter changes
    setCurrentPage(1);
  }, [searchQuery, isTopRated]);
  
  useEffect(() => {
    async function loadMovies() {
      setLoading(true);
      setError(null);
      
      try {
        let response;
        
        if (searchQuery) {
          response = await searchMovies(searchQuery, currentPage);
          document.title = `Search: ${searchQuery} - Movie Explorer`;
        } else if (isTopRated) {
          response = await getTopRatedMovies(currentPage);
          document.title = 'Top Rated Movies - Movie Explorer';
        } else {
          response = await fetchPopularMovies(currentPage);
          document.title = 'Popular Movies - Movie Explorer';
        }
        
        setMovies(response.results);
        setTotalPages(Math.min(response.total_pages, 500)); // TMDb API limits to 500 pages
      } catch (err) {
        setError('Failed to load movies. Please try again.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    
    loadMovies();
  }, [searchQuery, isTopRated, currentPage]);
  
  const handlePageChange = (page) => {
    setCurrentPage(page);
    window.scrollTo(0, 0);
  };
  
  if (loading) {
    // Show skeleton loading UI
    return (
      <div className="home-page">
        <h2 className="page-title">
          {searchQuery 
            ? `Search Results for "${searchQuery}"` 
            : isTopRated 
              ? 'Top Rated Movies' 
              : 'Popular Movies'}
        </h2>
        
        <div className="movie-grid">
          {Array(12).fill().map((_, index) => (
            <div key={index} className="movie-card-skeleton">
              <div className="skeleton-poster"></div>
              <div className="skeleton-info">
                <div className="skeleton-title"></div>
                <div className="skeleton-meta">
                  <div className="skeleton-rating"></div>
                  <div className="skeleton-year"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  if (error) {
    return <div className="error">{error}</div>;
  }
  
  if (movies.length === 0) {
    return <div className="no-results">No movies found. Try another search.</div>;
  }
  
  return (
    <div className="home-page">
      <h2 className="page-title">
        {searchQuery 
          ? `Search Results for "${searchQuery}"` 
          : isTopRated 
            ? 'Top Rated Movies' 
            : 'Popular Movies'}
      </h2>
      
      <div className="movie-grid">
        {movies.map(movie => (
          <MovieCard key={movie.id} movie={movie} />
        ))}
      </div>
      
      {totalPages > 1 && (
        <Pagination 
          currentPage={currentPage} 
          totalPages={totalPages} 
          onPageChange={handlePageChange} 
        />
      )}
    </div>
  );
}

export default HomePage;